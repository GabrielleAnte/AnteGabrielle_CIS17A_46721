var _player_8h =
[
    [ "Player", "class_player.html", "class_player" ],
    [ "BadRC", "class_player_1_1_bad_r_c.html", null ],
    [ "BadMns", "class_player_1_1_bad_mns.html", null ],
    [ "Badrc", "class_player_1_1_badrc.html", null ],
    [ "BadChc", "class_player_1_1_bad_chc.html", null ],
    [ "BadFlag", "class_player_1_1_bad_flag.html", null ],
    [ "LessTn1", "class_player_1_1_less_tn1.html", null ],
    [ "PLAYER_H", "_player_8h.html#aa3fab1fddd7bdec7c2d0867fb8aaad64", null ]
];