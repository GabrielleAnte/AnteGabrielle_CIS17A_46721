var class_in_brd =
[
    [ "InBrd", "class_in_brd.html#abad5d8c51327ec335917c2193b30086c", null ],
    [ "InBrd", "class_in_brd.html#a2b1b8305dee1ac861037a91e89fc99cd", null ],
    [ "~InBrd", "class_in_brd.html#a98d1079c6c4f44b2def006ade6b2b996", null ],
    [ "addMine", "class_in_brd.html#acb13a93095bb62ca7e10bdc62ef9cdad", null ],
    [ "addVal", "class_in_brd.html#ad8a4edd62f029ff83cf1f962928b6e68", null ],
    [ "celdata", "class_in_brd.html#a92a51ca05ea3fc01b976628951c2086c", null ],
    [ "dspBrd", "class_in_brd.html#aa6d18ae85e12c4315b32f79830ab7719", null ],
    [ "operator=", "class_in_brd.html#ab15a26f98623e2bbd5878605ab90cf9b", null ],
    [ "sweep", "class_in_brd.html#a1bbc35528c6f4473187f214cf8c6d99f", null ],
    [ "OutBrd::rdBrd", "class_in_brd.html#af23b58faaa163dc90ee5877394fb81f9", null ],
    [ "c", "class_in_brd.html#a462e1ba31741109b6a86cb369eb21377", null ]
];