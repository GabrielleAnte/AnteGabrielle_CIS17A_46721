var class_out_brd =
[
    [ "OutBrd", "class_out_brd.html#ad5af3e2f29a5e6a8f558ff2834aec12d", null ],
    [ "chkClr", "class_out_brd.html#a80ed53ea4a4ae752786cdc729cb4838f", null ],
    [ "ckFlg", "class_out_brd.html#aa92302a7d20fb2e20522e37ed48be906", null ],
    [ "clear", "class_out_brd.html#a82fca8e5252ad0300a663f07d2c8783d", null ],
    [ "dspBrd", "class_out_brd.html#a07ad712503dc56ce0c4a94b625c4780a", null ],
    [ "flag", "class_out_brd.html#aae382b8a171780c274e67a49328ef4d5", null ],
    [ "fRemain", "class_out_brd.html#aa9ac410197c494be9af5aa806fcf6ce1", null ],
    [ "loss", "class_out_brd.html#af608ac43b10bea381e951393c1b2c9e9", null ],
    [ "rdBrd", "class_out_brd.html#a0af7ee8eef4871714011bc8f4e9971a6", null ],
    [ "reveal", "class_out_brd.html#a4c07c984330c7d56eacb3154f41b731a", null ],
    [ "spcOpn", "class_out_brd.html#af35a0c9f121c0b2dddf81e88304343b7", null ],
    [ "unflag", "class_out_brd.html#ab33baa2658c6ccd009b3043fe389d0c4", null ],
    [ "win", "class_out_brd.html#a3b1441409df7b1460bdc5b57734b1064", null ],
    [ "cell", "class_out_brd.html#a433ae12184330fe2b4ee5b89b4322eb7", null ]
];