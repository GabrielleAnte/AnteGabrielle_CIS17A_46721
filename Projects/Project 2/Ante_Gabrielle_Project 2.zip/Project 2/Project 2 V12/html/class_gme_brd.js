var class_gme_brd =
[
    [ "GmeBrd", "class_gme_brd.html#a2920499850a4d6e438c2c12154bbd055", null ],
    [ "GmeBrd", "class_gme_brd.html#a9654654686735311aef97d49d37911bd", null ],
    [ "~GmeBrd", "class_gme_brd.html#a37d4716b5f4f495cd0d8b2b221b74e61", null ],
    [ "dspBrd", "class_gme_brd.html#a5b068f96bc311c6d2e7b1f7e2d5fe4e0", null ],
    [ "getCol", "class_gme_brd.html#a278e6bf2a51f6ff7fa5b81fcbbb33471", null ],
    [ "getMine", "class_gme_brd.html#accbce40e77b3a158eb8f6ed0378cc744", null ],
    [ "getRow", "class_gme_brd.html#a88556cfcca500806e96f998fee5a84e1", null ],
    [ "setCol", "class_gme_brd.html#ac9b58f005fbf43fef04596ebace1082e", null ],
    [ "setMine", "class_gme_brd.html#a08d5eda4c06a310c868668994c5d47b2", null ],
    [ "setRow", "class_gme_brd.html#a279ed4807b7864824f79a6e7dce87d6f", null ],
    [ "c", "class_gme_brd.html#aaecbdf613b29d5de293b100b52083e62", null ],
    [ "col", "class_gme_brd.html#add7a2f883bd9dbb4d70609536c1c3655", null ],
    [ "mine", "class_gme_brd.html#a380ced78a97eb23602ed3868eacff11c", null ],
    [ "row", "class_gme_brd.html#ad5835d62cf112b2687a577c8c3915307", null ]
];