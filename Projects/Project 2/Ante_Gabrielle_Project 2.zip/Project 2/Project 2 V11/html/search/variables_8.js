var searchData=
[
  ['name_210',['name',['../dd/d1f/class_game.html#a3704a89ccc3882ccbef9c258b65a4a76',1,'Game::name()'],['../d8/d53/class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player::name()']]],
  ['names_211',['names',['../df/d1b/class_stats.html#ad97a8291ffa012c4bc0bdd8e059e5537',1,'Stats']]],
  ['ncol_212',['ncol',['../dd/d11/class_cell.html#a02831844b99ef62b8cccda162977872b',1,'Cell::ncol()'],['../dd/d1f/class_game.html#a444f05e25120130ed2730d7756329ecf',1,'Game::ncol()']]],
  ['nmines_213',['nmines',['../dd/d1f/class_game.html#a532b1f133947e5ec0b1290cb2ccce644',1,'Game']]],
  ['nrow_214',['nrow',['../dd/d11/class_cell.html#a9918b04ec15f46b116493b77e07aa618',1,'Cell::nrow()'],['../dd/d1f/class_game.html#a628db27089dea207435a6c8620daca3f',1,'Game::nrow()']]],
  ['number_215',['number',['../d8/d53/class_player.html#af14f0d6ce7546bc1ded859df40cd8819',1,'Player']]]
];
