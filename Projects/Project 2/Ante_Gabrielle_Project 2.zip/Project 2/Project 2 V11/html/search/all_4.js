var searchData=
[
  ['flag_22',['flag',['../class_out_brd.html#aae382b8a171780c274e67a49328ef4d5',1,'OutBrd']]],
  ['fremain_23',['fRemain',['../class_out_brd.html#aa9ac410197c494be9af5aa806fcf6ce1',1,'OutBrd']]]
];
