var searchData=
[
  ['badchc_95',['BadChc',['../class_player_1_1_bad_chc.html',1,'Player']]],
  ['badflag_96',['BadFlag',['../class_player_1_1_bad_flag.html',1,'Player']]],
  ['badmns_97',['BadMns',['../class_player_1_1_bad_mns.html',1,'Player']]],
  ['badrc_98',['Badrc',['../class_player_1_1_badrc.html',1,'Player::Badrc'],['../class_player_1_1_bad_r_c.html',1,'Player::BadRC']]]
];
