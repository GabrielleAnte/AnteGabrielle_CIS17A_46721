var searchData=
[
  ['main_48',['main',['../_ante___gabrielle___project__2_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'Ante_Gabrielle_Project_2.cpp']]],
  ['mine_49',['mine',['../class_gme_brd.html#a380ced78a97eb23602ed3868eacff11c',1,'GmeBrd']]]
];
