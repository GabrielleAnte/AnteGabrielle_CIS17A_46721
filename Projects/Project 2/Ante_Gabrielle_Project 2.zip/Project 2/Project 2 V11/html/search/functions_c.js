var searchData=
[
  ['unflag_176',['unflag',['../class_out_brd.html#ab33baa2658c6ccd009b3043fe389d0c4',1,'OutBrd']]],
  ['update_177',['update',['../class_stats.html#a10e4f1d2ac81f33296dca7e24b0e3cbf',1,'Stats']]]
];
