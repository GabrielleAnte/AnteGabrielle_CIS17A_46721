var searchData=
[
  ['point_188',['point',['../class_stats.html#a0325b8816fe08b31eff6f6d82fd1d2e9',1,'Stats']]]
];
