var searchData=
[
  ['lesstn1_45',['LessTn1',['../class_player_1_1_less_tn1.html',1,'Player']]],
  ['loss_46',['loss',['../class_out_brd.html#af608ac43b10bea381e951393c1b2c9e9',1,'OutBrd']]],
  ['losses_47',['losses',['../class_stats.html#a5f1e6d7fe80b8fe9ceff95e54af484ab',1,'Stats']]]
];
