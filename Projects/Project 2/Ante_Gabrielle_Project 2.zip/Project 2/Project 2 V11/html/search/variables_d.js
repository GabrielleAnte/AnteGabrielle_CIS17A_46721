var searchData=
[
  ['value_223',['value',['../dd/d11/class_cell.html#a2a5e46b6fdcc414fa3736bbc193f62e8',1,'Cell']]]
];
