var searchData=
[
  ['inbrd_42',['InBrd',['../class_in_brd.html',1,'InBrd'],['../class_in_brd.html#abad5d8c51327ec335917c2193b30086c',1,'InBrd::InBrd()'],['../class_in_brd.html#a2b1b8305dee1ac861037a91e89fc99cd',1,'InBrd::InBrd(int r, int cl, int m)']]],
  ['inbrd_2ecpp_43',['InBrd.cpp',['../_in_brd_8cpp.html',1,'']]],
  ['inbrd_2eh_44',['InBrd.h',['../_in_brd_8h.html',1,'']]]
];
