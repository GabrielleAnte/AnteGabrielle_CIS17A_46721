var searchData=
[
  ['setbrd_69',['setBrd',['../class_player.html#a740b82f6723c1b4e985444caa4ab95e1',1,'Player::setBrd()'],['../class_player.html#a31e5f0df2e737d1163fe45c94d5b3190',1,'Player::setBrd(int r, int c, int m)']]],
  ['setcol_70',['setCol',['../class_gme_brd.html#ac9b58f005fbf43fef04596ebace1082e',1,'GmeBrd']]],
  ['setdisp_71',['setDisp',['../class_cell.html#a22e5aab236b2f42a4cec18652cce88fe',1,'Cell']]],
  ['setflgd_72',['setFlgd',['../class_cell.html#aa190ef553aef63dda30047619b39fe7a',1,'Cell']]],
  ['sethddn_73',['setHddn',['../class_cell.html#a89a43f48ffb2aacaf5961e46fd78e197',1,'Cell']]],
  ['setmine_74',['setMine',['../class_cell.html#a3e26b9878fa13187a7834e21ad1affa8',1,'Cell::setMine()'],['../class_gme_brd.html#a08d5eda4c06a310c868668994c5d47b2',1,'GmeBrd::setMine()']]],
  ['setname_75',['setName',['../class_player.html#a37fc1f766b05e107305976aa9e8d0fc4',1,'Player::setName()'],['../class_player.html#a21f5d3d0f858ecff23b604e907f36247',1,'Player::setName(string n)']]],
  ['setncol_76',['setncol',['../class_cell.html#ab0e328f5d053f7df313063bb3239fa09',1,'Cell']]],
  ['setnrow_77',['setnrow',['../class_cell.html#ae8de6c402ee3ca437b73a2839f0a34ba',1,'Cell']]],
  ['setrow_78',['setRow',['../class_gme_brd.html#a279ed4807b7864824f79a6e7dce87d6f',1,'GmeBrd']]],
  ['setsym_79',['setSym',['../class_cell.html#a0b22981cded7faf11c9313c165e90988',1,'Cell']]],
  ['setup_80',['setUp',['../class_game.html#ade11a025de0143ce182e2b9a83755144',1,'Game']]],
  ['setval_81',['setVal',['../class_cell.html#ae90b9eb1f9236ccf9054c25a1e1f915d',1,'Cell']]],
  ['shostrt_82',['shoStrt',['../class_game.html#afdd9eefc48c8e437253bd0723fe2aef6',1,'Game']]],
  ['spcopn_83',['spcOpn',['../class_out_brd.html#af35a0c9f121c0b2dddf81e88304343b7',1,'OutBrd']]],
  ['stats_84',['Stats',['../class_stats.html',1,'Stats&lt; T &gt;'],['../class_player.html#a5b525e04839b6cd3252b288b9db6bca6',1,'Player::stats()'],['../class_stats.html#ae1419ec347a13f0407adbb6452af3291',1,'Stats::Stats()']]],
  ['stats_2eh_85',['Stats.h',['../_stats_8h.html',1,'']]],
  ['stats_3c_20int_20_3e_86',['Stats&lt; int &gt;',['../class_stats.html',1,'']]],
  ['stats_5fh_87',['STATS_H',['../_stats_8h.html#a61e845bc0532143e8d808a9dd0f81b08',1,'Stats.h']]],
  ['sweep_88',['sweep',['../class_in_brd.html#a1bbc35528c6f4473187f214cf8c6d99f',1,'InBrd']]]
];
