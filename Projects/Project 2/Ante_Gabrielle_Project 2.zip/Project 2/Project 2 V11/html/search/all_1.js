var searchData=
[
  ['badchc_7',['BadChc',['../class_player_1_1_bad_chc.html',1,'Player']]],
  ['badflag_8',['BadFlag',['../class_player_1_1_bad_flag.html',1,'Player']]],
  ['badmns_9',['BadMns',['../class_player_1_1_bad_mns.html',1,'Player']]],
  ['badrc_10',['Badrc',['../class_player_1_1_badrc.html',1,'Player::Badrc'],['../class_player_1_1_bad_r_c.html',1,'Player::BadRC']]]
];
