var searchData=
[
  ['player_217',['player',['../dd/d1f/class_game.html#a6e48721b0532833b99fd5615a3628792',1,'Game']]],
  ['point_218',['point',['../df/d1b/class_stats.html#a0325b8816fe08b31eff6f6d82fd1d2e9',1,'Stats']]],
  ['pts_219',['pts',['../d8/d53/class_player.html#a258026b604c89c0c46afca64d50fd82b',1,'Player']]]
];
