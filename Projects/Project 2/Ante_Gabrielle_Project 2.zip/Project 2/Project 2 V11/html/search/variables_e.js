var searchData=
[
  ['wins_224',['wins',['../df/d1b/class_stats.html#adac1de891638fb0645b5c63cf2582451',1,'Stats']]]
];
