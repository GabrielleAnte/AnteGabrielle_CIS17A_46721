var searchData=
[
  ['rc_220',['rC',['../dd/d1f/class_game.html#a18205f981b4ecee4fcdd36aa690afc18',1,'Game']]],
  ['row_221',['row',['../d7/d12/class_gme_brd.html#ad5835d62cf112b2687a577c8c3915307',1,'GmeBrd::row()'],['../d8/d53/class_player.html#ab4e6ed0131da3921bc80b39f9b455dc9',1,'Player::row()']]]
];
