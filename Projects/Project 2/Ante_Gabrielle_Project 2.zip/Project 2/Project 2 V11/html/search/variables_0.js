var searchData=
[
  ['col_181',['col',['../class_gme_brd.html#add7a2f883bd9dbb4d70609536c1c3655',1,'GmeBrd']]]
];
