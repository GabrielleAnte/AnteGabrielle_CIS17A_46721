var indexSectionsWithContent =
{
  0: "abcdfgilmnoprsuw~",
  1: "bcgilops",
  2: "acgiops",
  3: "acdfgilmoprsuw~",
  4: "clmnprw",
  5: "o",
  6: "cgps",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros",
  7: "Pages"
};

