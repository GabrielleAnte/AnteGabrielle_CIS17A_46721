var searchData=
[
  ['play_153',['play',['../class_game.html#aa333825d0bca80e91e53c7e23f053405',1,'Game']]],
  ['player_154',['Player',['../class_player.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8',1,'Player::Player()'],['../class_player.html#a0fb947f3bd20596cbff1f576711ce90e',1,'Player::Player(string n)']]],
  ['points_155',['points',['../class_player.html#a1bba8328130b421db32a59fdc3d0292f',1,'Player::points()'],['../class_stats.html#a12f9b68f68c8ab4ad29273da3b404cd7',1,'Stats::points()']]]
];
