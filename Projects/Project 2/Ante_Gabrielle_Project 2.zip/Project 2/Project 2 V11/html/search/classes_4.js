var searchData=
[
  ['lesstn1_103',['LessTn1',['../class_player_1_1_less_tn1.html',1,'Player']]]
];
