var searchData=
[
  ['win_106',['win',['../d0/df1/class_out_brd.html#a3b1441409df7b1460bdc5b57734b1064',1,'OutBrd']]],
  ['wins_107',['wins',['../df/d1b/class_stats.html#adac1de891638fb0645b5c63cf2582451',1,'Stats']]]
];
