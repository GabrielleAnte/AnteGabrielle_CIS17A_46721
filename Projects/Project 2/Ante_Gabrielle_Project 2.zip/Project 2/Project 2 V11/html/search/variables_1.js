var searchData=
[
  ['losses_182',['losses',['../class_stats.html#a5f1e6d7fe80b8fe9ceff95e54af484ab',1,'Stats']]]
];
