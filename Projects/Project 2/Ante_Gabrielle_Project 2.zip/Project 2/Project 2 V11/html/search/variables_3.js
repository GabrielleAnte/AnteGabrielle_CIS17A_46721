var searchData=
[
  ['names_184',['names',['../class_stats.html#ad97a8291ffa012c4bc0bdd8e059e5537',1,'Stats']]],
  ['ncol_185',['ncol',['../class_game.html#a444f05e25120130ed2730d7756329ecf',1,'Game']]],
  ['nmines_186',['nmines',['../class_game.html#a532b1f133947e5ec0b1290cb2ccce644',1,'Game']]],
  ['nrow_187',['nrow',['../class_game.html#a628db27089dea207435a6c8620daca3f',1,'Game']]]
];
